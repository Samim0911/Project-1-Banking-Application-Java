public class BankAccount {

    private int accountNumber;
    private int pin;
    private String name;
    private double currentBalance;

    // Constructor
    public BankAccount(int accountNumber, int pin, String name, double currentBalance) {
        this.accountNumber = accountNumber;
        this.pin = pin;
        this.name = name;
        this.currentBalance = currentBalance;
    }

    // Deposit money
    public void deposit(double amount) {
        if (amount > 0) {
            currentBalance += amount;
            System.out.println("Deposit successful.");
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    // Withdraw money
    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid withdrawal amount.");
        } else if (amount > currentBalance) {
            System.out.println("Insufficient funds.");
        } else {
            currentBalance -= amount;
            System.out.println("Withdrawal successful.");
        }
    }

    // Check balance
    public void checkBalance() {
        System.out.printf("Current Balance: $%.2f%n", currentBalance);
    }

    // Validate PIN
    public boolean validatePin(int inputPin) {
        return pin == inputPin;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public String getName() {
        return name;
    }
}