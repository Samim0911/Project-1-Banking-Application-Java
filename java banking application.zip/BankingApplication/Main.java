import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Bank bank = new Bank();

        System.out.println("=================================");
        System.out.println("   Welcome to Java Bank System");
        System.out.println("=================================");

        System.out.print("Enter Account Number: ");
        int accountNumber = scanner.nextInt();

        System.out.print("Enter PIN: ");
        int pin = scanner.nextInt();

        BankAccount userAccount = bank.findAccount(accountNumber, pin);

        if (userAccount != null) {
            bank.performTransaction(userAccount);
        } else {
            System.out.println("Invalid account number or PIN.");
        }

        scanner.close();
    }
}