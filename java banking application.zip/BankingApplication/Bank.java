import java.util.ArrayList;
import java.util.Scanner;

public class Bank {

    private ArrayList<BankAccount> accounts;
    private Scanner scanner;

    public Bank() {
        accounts = new ArrayList<>();
        scanner = new Scanner(System.in);

        // Predefined accounts
        accounts.add(new BankAccount(1001, 1234, "Samim Malik", 500.00));
        accounts.add(new BankAccount(1002, 2345, "Master Vick", 1200.00));
        accounts.add(new BankAccount(1003, 3456, "James Bond", 1500.00));
    }

    // Find account
    public BankAccount findAccount(int accountNumber, int pin) {
        for (BankAccount account : accounts) {
            if (account.getAccountNumber() == accountNumber && account.validatePin(pin)) {
                return account;
            }
        }
        return null;
    }

    // Perform transactions
    public void performTransaction(BankAccount account) {

        int choice;

        do {
            System.out.println("\nWelcome, " + account.getName());
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            choice = scanner.nextInt();

            switch (choice) {

                case 1:
                    account.checkBalance();
                    break;

                case 2:
                    System.out.print("Enter deposit amount: $");
                    double depositAmount = scanner.nextDouble();
                    account.deposit(depositAmount);
                    break;

                case 3:
                    System.out.print("Enter withdrawal amount: $");
                    double withdrawAmount = scanner.nextDouble();
                    account.withdraw(withdrawAmount);
                    break;

                case 4:
                    System.out.println("Thank you for banking with us.");
                    break;

                default:
                    System.out.println("Invalid option.");
            }

        } while (choice != 4);
    }
}